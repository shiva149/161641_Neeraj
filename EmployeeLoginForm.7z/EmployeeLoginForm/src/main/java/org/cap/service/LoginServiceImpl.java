package org.cap.service;

import org.cap.dao.ILoginDao;
import org.cap.dao.LoginDaoImpl;
import org.cap.model.LoginBean;

public class LoginServiceImpl implements ILoginService{
	ILoginDao ilogindao=new LoginDaoImpl();
	@Override
	public boolean isValidLogin(LoginBean loginbean) {
		if(ilogindao.isValidLogin(loginbean)) {
			return true;	
			}
		return false;
	}


	

}
