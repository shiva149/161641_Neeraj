package org.cap.model;

public class LoginBean {
	private String username;
	private String userpassword;
	
	public LoginBean(String username, String password) {
		super();
		this.username = username;
		this.userpassword = password;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getuserPassword() {
		return userpassword;
	}
	public void setPassword(String password) {
		this.userpassword = password;
	}
	
	@Override
	public String toString() {
		return "LoginBean [username=" + username + ", password=" + userpassword + "]";
	}
	
	

}
