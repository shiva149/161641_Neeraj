package org.cap.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.cap.model.LoginBean;

public class LoginDaoImpl implements ILoginDao {

	@Override
	public boolean isValidLogin(LoginBean loginbean) {
		String sql="select * from adminlogin where username=? and userpassword=?";
		
		try(PreparedStatement pst=getMySQLDBConnection().prepareStatement(sql);) {
			
			pst.setString(1, loginbean.getUsername());
			pst.setString(2,loginbean.getuserPassword());
			ResultSet rs=pst.executeQuery();
			if(rs.next()) {
				return true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}catch(Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	private Connection getMySQLDBConnection() {
		
		Connection con=null;
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/capdb","root","India123");
			return con;
		}catch(SQLException e) {
			e.printStackTrace();
		}catch(Exception e) {
			e.printStackTrace();
		}
		return null;
	}

}
