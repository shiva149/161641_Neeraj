package org.cap.dao;

import org.cap.model.LoginBean;

public interface ILoginDao {
	public boolean isValidLogin(LoginBean loginbean);

}
