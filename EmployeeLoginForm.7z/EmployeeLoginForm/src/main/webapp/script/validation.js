function validate(){
	var flag=false;
	var UserName=f1.username.value;
	var Password=f1.password.value;
	if(UserName==""||UserName==null){
		document.getElementById('userErrMsg').innerHTML="* Please enter user Name";
			flag=false;
	}else if(Password==""||Password==null){
		document.getElementById('pwdErrMsg').innerHTML="* Please enter user Password";
			document.getElementById('userErrMsg').innerHTML="";
			flag=false;
	}else{
		flag=true;
	}
	
	return flag;
}