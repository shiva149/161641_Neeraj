package com.capg.inheritance;

import java.time.LocalDate;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class MainClass {

	public static void main(String args[]) {
		
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpademo");
		EntityManager entityManager=emf.createEntityManager();
		EntityTransaction transaction=entityManager.getTransaction(); 
		
		transaction.begin();
		
		Project project=new Project(101,"Registration");
	
		
		Module module=new Module();
		module.setProjectId(121);
		module.setProjectName("blog");
		module.setModuleName("Login page");
		
		Task task=new Task();
		task.setProjectId(211);
		task.setProjectName("Home Automation");
		task.setModuleName("Execution");
		task.setTaskName("Validation");
		task.setTaskEndDate(LocalDate.of(2017, 10, 8));
		
		entityManager.persist(project);
		entityManager.persist(module);
		entityManager.persist(task);
		
		transaction.commit();
		entityManager.close();
	}
}
