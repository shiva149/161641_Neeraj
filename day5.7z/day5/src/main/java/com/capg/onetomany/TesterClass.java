package com.capg.onetomany;

import java.time.LocalDate;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class TesterClass {

	public static void main(String[] args) {
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpademo");
		EntityManager entityManager=emf.createEntityManager();
		EntityTransaction transaction=entityManager.getTransaction(); 
		
		transaction.begin();
		Company infosys=new Company("infosys");
		Company capg=new Company("Capgemini");
		
		Employee employee=new Employee(101,"miles",LocalDate.now(),infosys);
		Employee employee1=new Employee(102,"patrick",LocalDate.now(),capg);
		Employee employee2=new Employee(103,"bush",LocalDate.now(),infosys);
		Employee employee3=new Employee(104,"nancy",LocalDate.now(),capg);
		
		entityManager.persist(infosys);
		entityManager.persist(capg);
		entityManager.persist(employee);
		entityManager.persist(employee1);
		entityManager.persist(employee2);
		entityManager.persist(employee3);
		transaction.commit();
		entityManager.close();

	}

}
