package com.capg.manytomany;



import java.time.LocalDate;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class MainClass {

	public static void main(String[] args) {
	
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpademo");
		EntityManager entityManager=emf.createEntityManager();
		EntityTransaction transaction=entityManager.getTransaction(); 
		
		transaction.begin();
		
		Events corejava=new Events();
		corejava.setEventId("101-corejava");
		corejava.setEventName("corejava");
		corejava.setEventDate(LocalDate.of(2005, 8, 15));
		
		Events dotnet=new Events();
		dotnet.setEventId("102-dotnet");
		dotnet.setEventName("dotnet");
		dotnet.setEventDate(LocalDate.of(2004, 8, 19));
		
		Events oracle=new Events();
		oracle.setEventId("103-oracle");
		oracle.setEventName("oracle");
		oracle.setEventDate(LocalDate.of(2008, 8, 22));
		
		Delegates jack=new Delegates(112,"jack");
		Delegates tom=new Delegates(15,"tom");
		Delegates peter=new Delegates(115,"peter");
		Delegates john=new Delegates(123,"john");
		Delegates mike=new Delegates(156,"mike");
		
		
		entityManager.persist(jack);
		entityManager.persist(tom);
		entityManager.persist(peter);
		entityManager.persist(john);
		entityManager.persist(mike);
		
		
		jack.getEvents().add(corejava);
		tom.getEvents().add(dotnet);
		jack.getEvents().add(oracle);
		peter.getEvents().add(corejava);
		john.getEvents().add(dotnet);
		tom.getEvents().add(corejava);
		mike.getEvents().add(dotnet);
		peter.getEvents().add(oracle);
		

		
		
		entityManager.persist(corejava);
		entityManager.persist(oracle);
		entityManager.persist(dotnet);
		
		
		
		transaction.commit();
		entityManager.close();
	}

}
