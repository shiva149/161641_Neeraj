package org.cap.model;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class Test {
	public static void main(String[] args) {
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpademo");
		EntityManager entityManager=emf.createEntityManager();
		EntityTransaction transaction=entityManager.getTransaction();
		transaction.begin();
		
		Routetable routetable=new Routetable();
		routetable.setRoute_path("MIPL-Crompet");
		routetable.setNo_of_seats_occupied(19);
		routetable.setTotal_seats(60);
		routetable.setBus_no("TN-3121");
		routetable.setDriver_name("Peter");
		routetable.setTotal_km(48.97);
		LoginBean loginBean=new LoginBean("Elon", "elon@123");
		LoginBean loginBean1=new LoginBean("Max", "max@123");
		LoginBean loginBean2=new LoginBean("Jack", "jack@123");
		
		entityManager.persist(routetable);
		entityManager.persist(loginBean);
		entityManager.persist(loginBean1);
		entityManager.persist(loginBean2);
		
		transaction.commit();
		entityManager.close();
	}

}
