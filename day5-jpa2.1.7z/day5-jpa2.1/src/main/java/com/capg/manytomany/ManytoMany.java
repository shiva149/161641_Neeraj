package com.capg.manytomany;

import java.time.LocalDate;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class MainClass {

	public static void main(String[] args) {
	
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpademo");
		EntityManager entityManager=emf.createEntityManager();
		EntityTransaction transaction=entityManager.getTransaction(); 
		
		transaction.begin();
		
		Events corejava=new Events();
		corejava.setEventId("1001-COREJAVA");
		corejava.setEventName("COREJAVA");
		corejava.setEventDate(LocalDate.of(1995, 11, 25));
		
		Events python=new Events();
		python.setEventId("1002-PYTHON");
		python.setEventName("PYTHON");
		python.setEventDate(LocalDate.of(2001, 10, 19));
		
		Events angularjs=new Events();
		angularjs.setEventId("1003-ANGULARJS");
		angularjs.setEventName("ANGULARJS");
		angularjs.setEventDate(LocalDate.of(2005, 11, 10));
		
		Delegates shiva=new Delegates(122,"jack");
		Delegates neeraj=new Delegates(215,"tom");
		Delegates manoj=new Delegates(125,"peter");
		Delegates akhil=new Delegates(156,"mark");
		Delegates vamsi=new Delegates(156,"mike");
		
		entityManager.persist(jack);
		entityManager.persist(tom);
		entityManager.persist(peter);
		entityManager.persist(mark);
		entityManager.persist(mike);
		
		mike.getEvents().add(corejava);
		mike.getEvents().add(python);
		peter.getEvents().add(angularjs);
		mark.getEvents().add(corejava);
		tom.getEvents().add(python);
		tom.getEvents().add(corejava);
		jack.getEvents().add(python);
		jack.getEvents().add(angularjs);
		

		
		
		entityManager.persist(corejava);
		entityManager.persist(angularjs);
		entityManager.persist(python);
		
		
		
		transaction.commit();
		entityManager.close();
	}

}
